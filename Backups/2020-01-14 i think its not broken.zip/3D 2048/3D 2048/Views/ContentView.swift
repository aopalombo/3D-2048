//
//  ContentView.swift
//  3D 2048
//
//  Created by Andrew Palombo on 08/01/2021.
//

import SwiftUI
import RealityKit

struct ContentView : View {
	@EnvironmentObject var game: Game //{
//		didSet {
//			let encoder = JSONEncoder()
//			if let data = try? encoder.encode(self.game) {
//				UserDefaults.standard.set(data, forKey: "CurrentGame")
//			}
			
			// Update statistics
			// High score
//			print(highScore)
//			if game.score > highScore {
//				highScore = game.score
//			}
//
//			// Highest tile
//			for x in 0 ... 2 {
//				for y in 0 ... 2 {
//					for z in 0 ... 2 {
//						if game.matrix[x][y][z] > highestTile {
//							highestTile = game.matrix[x][y][z]
//						}
//					}
//				}
//			}
//
//			// Games won
//			if game.gameWon && !game.gameWonRecorded {
//				gamesWon += 1
//				game.gameWonRecorded = true
//			}
//
//
//			let encoder = JSONEncoder()
//			if let data = try? encoder.encode(self.game) {
//				UserDefaults.standard.set(data, forKey: "CurrentGame")
//			}
//		}
	//}
	
	@State private var inPlayMode = false
	@State private var focusEntityNeeded = false
	@State private var placeGrid = false
//	@State private var tilesForTranslation = [(start: Coordinates, finish: Coordinates)]()
//	@State private var tilesForPlacement = [(tileName: String, coordinates: Coordinates)]()
//	@State private var tilesForRemoval = [Coordinates]()
//	@State private var tilePositions = [(tileId: String, coordinates: Coordinates?)]()
	@State private var resetGameAr = false
	
	// Default start value = 0
	@State private var highScore = UserDefaults.standard.integer(forKey: "HighScore") {
		didSet {
			UserDefaults.standard.set(highScore, forKey: "HighScore")
		}
	}
	@State private var highestTile = UserDefaults.standard.integer(forKey: "HighestTile") {
		didSet {
			UserDefaults.standard.set(highestTile, forKey: "HighestTile")
		}
	}
	@State private var gamesWon = UserDefaults.standard.integer(forKey: "GamesWon") {
		didSet {
			UserDefaults.standard.set(gamesWon, forKey: "GamesWon")
		}
	}
	
	private var models: [String: Model] = {
		// Get filenames dynamically
		let fileManager = FileManager.default
		
		guard let path = Bundle.main.resourcePath, let files = try? fileManager.contentsOfDirectory(atPath: path) else {
			return [:]
		}
		
		var models = [String: Model]()
		for filename in files where filename.hasSuffix("usdz") {
			let modelName = filename.replacingOccurrences(of: ".usdz", with: "")
			let model = Model(modelName: modelName)
			
			models[modelName] = model
		}
		
		return models
	}()
	
//	@State private var translating = true {
//		didSet {
//			if translating {
//				self.removing = false
//				self.adding = false
//			}
//		}
//	}
//	@State private var removing = false {
//		didSet {
//			if removing {
//				self.translating = false
//				self.adding = false
//			}
//		}
//	}
//	@State private var adding = false {
//		didSet {
//			if adding {
//				self.translating = false
//				self.removing = false
//			}
//		}
//	}
	
	init() {
		// By accessing the contents of the computed property 'models', the modelEntity's are also loaded on app launch - ready for use.
		for (_, model) in self.models {
			print("DEBUG: loading \(model.modelName)")
		}
	}
	
    var body: some View {
		ZStack(alignment: .center) {
			ARViewContainer(inPlayMode: self.$inPlayMode, focusEntityNeeded: self.$focusEntityNeeded, placeGrid: self.$placeGrid, resetGameAr: self.$resetGameAr, models: self.models).edgesIgnoringSafeArea(.all)
			
			if self.inPlayMode {
				GameView(inPlayMode: self.$inPlayMode, focusEntityNeeded: self.$focusEntityNeeded, placeGrid: self.$placeGrid, resetGameAr: self.$resetGameAr, highScore: $highScore, highestTile: $highestTile, gamesWon: $gamesWon, models: self.models)
			} else {
				MenuView(inPlayMode: self.$inPlayMode, focusEntityNeeded: self.$focusEntityNeeded, highScore: $highScore, highestTile: $highestTile, gamesWon: $gamesWon).edgesIgnoringSafeArea(.all)
			}
		}
    }
}

struct ARViewContainer: UIViewRepresentable {
	@EnvironmentObject var game: Game
	
	@Binding var inPlayMode: Bool
	@Binding var focusEntityNeeded: Bool
	@Binding var placeGrid: Bool
//	@Binding var tilesForTranslation: [(start: Coordinates, finish: Coordinates)]
//	@Binding var tilesForPlacement: [(tileName: String, coordinates: Coordinates)]
//	@Binding var tilesForRemoval: [Coordinates]
//	@Binding var tilePositions: [(tileId: String, coordinates: Coordinates?)]
	@Binding var resetGameAr: Bool
	
	var models: [String: Model]
	
	var nextTileId: String {
		String(self.game.tilePositions.count)
	}
	
//	@Binding var translating: Bool
//	@Binding var removing: Bool
//	@Binding var adding: Bool
    
    func makeUIView(context: Context) -> FocusARView {
        
		FocusARView(frame: .zero)//ARView(frame: .zero)
        
    }
    
	// MARK: Update UI
    func updateUIView(_ uiView: FocusARView, context: Context) {
		// When updating the AR view:
		// Enable/disable the focus entity
		if self.focusEntityNeeded {
			uiView.show()
		} else {
			uiView.hide()
		}
		
		// Remove all AR objects, when menu is selected
		if !self.inPlayMode {
			for anchor in uiView.scene.anchors where anchor.name != "FocusEntity" {
				uiView.scene.removeAnchor(anchor)
			}
		}
		
		// Remove all tiles, when a new game is started
		if self.resetGameAr {
			let gameAnchorEntity = uiView.scene.findEntity(named: "Game")!
			for modelEntity in gameAnchorEntity.children where modelEntity.name != "Frame" {
				gameAnchorEntity.removeChild(modelEntity)
			}
			DispatchQueue.main.async {
				resetGameAr = false
			}
		}
		
		// Place the grid
		if self.placeGrid {
			let model = models["Frame"]!
			// May not exist yet as it is loaded asynchronously
			if let modelEntity = model.modelEntity {
				print("DUBUG: adding model to scene - \(model.modelName)")
				
				let anchorEntity = AnchorEntity(plane: .any)
				anchorEntity.name = "Game"
				modelEntity.name = "Frame"
				anchorEntity.addChild(modelEntity)
				
				uiView.scene.addAnchor(anchorEntity)
				
			} else {
				print("DEBUG: unable to load modelEntity for \(model.modelName)")
			}
			
			// Once object has been added, it does not need to be added again
			// Add this to queue to avoid conflicting messages
			DispatchQueue.main.async {
				self.placeGrid = false
			}
		}
		
		// MARK: Placing Tiles:
//		if self.translating {
//
//		}
		DispatchQueue.main.async {
			// TRANSLATE TILES
//			print(self.game.tilesForTranslation)
			for index in 0 ..< self.game.tilesForTranslation.count {
				let tile = self.game.tilesForTranslation[index]
				// Find tileId
				var tileId: String?
				for tilePosition in self.game.tilePositions {
					if tilePosition.coordinates == tile.start {
						tileId = tilePosition.tileId
						break
					}
				}
				
				// Get access to entities needed for translation
				let gameAnchorEntity = uiView.scene.findEntity(named: "Game")!
				print(self.game.tilePositions)
				print(self.game.tilesForTranslation)
				let currentTileEntity = gameAnchorEntity.findEntity(named: tileId!)!
				
				// Find new tile position
				let centrePosition = gameAnchorEntity.findEntity(named: "Frame")!.position
				
				var zeroPosition = centrePosition
				zeroPosition.x -= 0.05
				zeroPosition.y +=  0.005
				zeroPosition.z -= 0.05
				
				var finalPosition = zeroPosition
				finalPosition.x += Float(tile.finish.x) * 5.0 * 0.01
				finalPosition.y += Float(tile.finish.y) * 5.0 * 0.01
				finalPosition.z += Float(tile.finish.z) * 5.0 * 0.01
				
				// Translate tile
				currentTileEntity.position = finalPosition
				
				
				// Update tilePositions
//				DispatchQueue.main.async {
//					for index in 0 ..< self.game.tilePositions.count {
//						if self.game.tilePositions[index].tileId == tileId! {
//							self.game.tilePositions[index].coordinates = tile.finish
//							break
//						}
//					}
//	//				self.game.tilesForTranslation.remove(at: index)
//				}
			}
		}
		// Update tilePositions
		DispatchQueue.main.async {
			for tile in game.tilesForTranslation {
				for index in 0 ..< game.tilePositions.count {
					if game.tilePositions[index].coordinates == tile.start {
						game.tilePositions[index].coordinates = tile.finish
					}
				}
			}
		}
		
		
		DispatchQueue.main.async {
			self.game.tilesForTranslation = []
//			self.removing = true
			
			
		}
		DispatchQueue.main.async {
			// REMOVE TILES
			for coordinates in self.game.tilesForRemoval {
				// Find tileId
	//				var tileId: String?
				var tileIds = [String]()
				for tilePosition in self.game.tilePositions {
					if tilePosition.coordinates == coordinates {
	//						tileId = tilePosition.tileId
						tileIds.append(tilePosition.tileId)
	//						break
					}
				}
				
				if tileIds.count > 1 {
					print("MORE THAN TWO")
				}
				print(self.game.tilesForRemoval)
				print(self.game.tilePositions)
				for tileId in tileIds {
					// Remove tile entity from anchor
					let gameAnchorEntity = uiView.scene.findEntity(named: "Game")!
					let tileEntityForRemoval = gameAnchorEntity.findEntity(named: tileId)!
	//				gameAnchorEntity.removeChild(tileEntityForRemoval)
					gameAnchorEntity.removeChild(tileEntityForRemoval)
					
					// Set coordinates of tile in tilePositions to nil to indicated tile is removed
//					DispatchQueue.main.async {
//						gameAnchorEntity.removeChild(tileEntityForRemoval)
//						for index in 0 ..< self.game.tilePositions.count {
//							if self.game.tilePositions[index].tileId == tileId {
//								self.game.tilePositions[index].coordinates = nil
//								break
//							}
//						}
//					}
				}
	//				// Remove tile entity from anchor
	//				let gameAnchorEntity = uiView.scene.findEntity(named: "Game")!
	//				let tileEntityForRemoval = gameAnchorEntity.findEntity(named: tileId!)!
	////				gameAnchorEntity.removeChild(tileEntityForRemoval)
	//
	//				// Set coordinates of tile in tilePositions to nil to indicated tile is removed
	//				DispatchQueue.main.async {
	//					gameAnchorEntity.removeChild(tileEntityForRemoval)
	//					for index in 0 ..< self.tilePositions.count {
	//						if self.tilePositions[index].tileId == tileId! {
	//							self.tilePositions[index].coordinates = nil
	//							break
	//						}
	//					}
	//				}
				
			}
		}
		
		// Set coordinates of tile in tilePositions to nil to indicated tile is removed
		DispatchQueue.main.async {
			for coordinates in self.game.tilesForRemoval {
				for index in 0 ..< game.tilePositions.count {
					if game.tilePositions[index].coordinates == coordinates {
						game.tilePositions[index].coordinates = nil
					}
				}
			}
		}
		
		DispatchQueue.main.async {
			self.game.tilesForRemoval = []
//				self.adding = true
			
		}
		
		
		DispatchQueue.main.async {
			// PLACE NEW TILES
//				print(self.game.tilesForPlacement)
			for index in 0 ..< self.game.tilesForPlacement.count {
				let tile = self.game.tilesForPlacement[index]
				let model = models[tile.tileName]!
				
				if let modelEntity = model.modelEntity {
					print("DUBUG: adding model to scene - \(model.modelName)")
					
					// Clone the model entity to allow multiple simultaneous occurrences of the same tile value
					let clonedModelEntity = modelEntity.clone(recursive: true)
					
					// In order for entities to be placed relative to each other, they must all be child entities of the same
					// anchor entity.
					let gameAnchorEntity = uiView.scene.findEntity(named: "Game")!
					let centrePosition = gameAnchorEntity.findEntity(named: "Frame")!.position
					
					// Find tile position
					var zeroPosition = centrePosition
					zeroPosition.x -= 0.05
					zeroPosition.y +=  0.005
					zeroPosition.z -= 0.05
					
					var finalPosition = zeroPosition
					finalPosition.x += Float(tile.coordinates.x) * 5.0 * 0.01
					finalPosition.y += Float(tile.coordinates.y) * 5.0 * 0.01
					finalPosition.z += Float(tile.coordinates.z) * 5.0 * 0.01
					
					// Add relevant data to tile entity
//						clonedModelEntity.name = self.nextTileId
					clonedModelEntity.position = finalPosition
					
					// Add tile to relevant data structures
//						gameAnchorEntity.addChild(clonedModelEntity)
					clonedModelEntity.name = self.nextTileId
					gameAnchorEntity.addChild(clonedModelEntity)
//						self.game.tilePositions.append((tileId: clonedModelEntity.name, coordinates: tile.coordinates))
					self.game.tilePositions.append(TilePosition(tileId: clonedModelEntity.name, coordinates: tile.coordinates))
//					DispatchQueue.main.async { // nextTileId depends on this structure, so it can only be updated after use of nextTileId is complete
//						clonedModelEntity.name = self.nextTileId
//						gameAnchorEntity.addChild(clonedModelEntity)
////						self.game.tilePositions.append((tileId: clonedModelEntity.name, coordinates: tile.coordinates))
//						self.game.tilePositions.append(TilePosition(tileId: clonedModelEntity.name, coordinates: tile.coordinates))
//					}
//						DispatchQueue.main.async {
////							self.game.tilesForPlacement.remove(at: <#T##Int#>)
//						}
					
				} else {
					print("DEBUG: unable to load modelEntity for \(model.modelName)")
				}
			}
//				DispatchQueue.main.async {
//					self.game.tilesForPlacement = []
////					self.translating = true
//				}
		}
		
//		DispatchQueue.main.async {
//			for tile in game.tilesForPlacement {
//				game.tilePositions.append(TilePosition(tileId: nextTileId, coordinates: tile.coordinates))
//			}
//		}
		
		DispatchQueue.main.async {
			self.game.tilesForPlacement = []
//					self.translating = true
		}
		
		
		
		
		// MAY BE NECESSARY TO ADD NEW TILES AND REMOVING TILES TO QUEUE TO AVOID CONFLICTS
//		DispatchQueue.main.async {
//			<#code#>
//		}
//		if self.removing {
//
//		}
		
		
//		if self.adding {
//
//		}
		
		
	}
}

#if DEBUG
struct ContentView_Preview : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif
