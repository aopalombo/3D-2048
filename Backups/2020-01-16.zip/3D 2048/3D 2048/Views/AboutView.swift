//
//  AboutView.swift
//  3D 2048
//
//  Created by Andrew Palombo on 08/01/2021.
//

import SwiftUI

struct AboutView: View {
	@Environment(\.presentationMode) var presentationMode
	
    var body: some View {
		VStack {
			HStack {
				Spacer()
				Button(action: {
						self.presentationMode.wrappedValue.dismiss()}) {
					Image(systemName: "xmark.circle.fill")
						.foregroundColor(.secondary)
						.font(.system(size: 25, weight: .bold))
						.padding([.top, .trailing])
				}
			}
			Text("About 3D 2048")
				.font(.largeTitle)
				.fontWeight(.bold)
				.foregroundColor(.black)
				.minimumScaleFactor(0.8)
				.padding([.bottom, .leading, .trailing])
			Spacer()
			Form {
				Section {
					Link("App Support", destination: URL(string: "https://aopalombo.wixsite.com/3d2048/app-support")!)
						.accentColor(.black)
				}
				Section {
					Link("Privacy Policy", destination: URL(string: "https://aopalombo.wixsite.com/3d2048/privacy-policy")!)
						.accentColor(.black)
				}
				Section {
					Text("© Andrew Palombo")
				}
				Section {
					Link("Original 2048 by Gabriele Cirulli", destination: URL(string: "https://play2048.co")!)
						.accentColor(.black)
				}
			}
		}
		.background(Color(UIColor.systemBackground))
    }
}

struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
